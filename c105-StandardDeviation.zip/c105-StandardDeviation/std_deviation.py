
import math
import csv
with open('data.csv', newline='') as f:
    reader = csv.reader(f)
    file_data=list(reader)

data=[]
sum=0


for i in file_data[0]:
    print(i)
    data.append(float(i))
    sum=sum+float(i)

n=len(data)
mean = sum / n

print(mean,sum)

squaredsum=0
for number in data:
    a = int(number) - mean
    a= a**2
    squaredsum =squaredsum + a


result = squaredsum/ n

std_deviation = math.sqrt(result)
print(std_deviation)

