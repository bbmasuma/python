import cv2

def takepic():
    #initializing the cam
    videoOn= cv2.VideoCapture(0)
    result=True

    while(result):
        # reading what the cam has captured
        ret,frame=videoOn.read()

        # writing the image that has been captured
        cv2.imwrite("NewPic1.jpg",frame)
        result=False
    
    videoOn.release()
    cv2.destroyAllWindows()

takepic()