import cv2
import random
import time
import dropbox

def ts():
    rn=random.randint(0,100)
    vco=cv2.VideoCapture(0)
    result=True
    while(result):
        ret,frame=vco.read()
        image_name="NewPicture"+str(rn)+".jpg"
        cv2.imwrite(image_name,frame)
        result=False
    vco.release()
    cv2.destroyAllWindows()
    return image_name


def upload_file(file_name):
    access_token = 'sl.AvtdKMp367MsY-uflK0jvOJX0jMpsd4U3lsyxeX8p90JILnwqGjBAAtKvf6sxrrpeB-dGfoBdJ4h5sn8oqBrmdAVsTdUb8XGZ8Jp2-WTvD9izihGVXXrYwc9c8R4PY91pC2G7LPMxdg'
    file_from = file_name 
    file_to = '/Mine/'+file_name    #folder name in dropbox followed by the file name 
    dbx = dropbox.Dropbox(access_token)
    f = open(file_from, 'rb')
    dbx.files_upload(f.read(), file_to,mode=dropbox.files.WriteMode.overwrite)


def main():
    count=0
    while(count<5):
        name=ts()
        print(name)
        upload_file(name)
        time.sleep(30)
        count=count+1
            

main()
