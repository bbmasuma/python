import dropbox
access_token = 'sl.Avp7RcDNnUQiI_U0TVIz4T4nrf7FbAN4ZC2xQfwhOivFQ2iRHyelCpgokMM8ljAekd6ekiGuwITv2_PqKLtxEjep5CnkvN11XwD9U5rPuc4CpscuzQgbqALDz6n4QoYQ6sGca60'
file_from = 'test.txt'  
file_to = '/Mine/test.txt'    #folder name in dropbox followed by the file name 
def upload_file(file_from, file_to):
    dbx = dropbox.Dropbox(access_token)
    f = open(file_from, 'rb')
    dbx.files_upload(f.read(), file_to)
upload_file(file_from,file_to)