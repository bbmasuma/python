from collections import Counter

new_string="whitehatjr"
counter_data=Counter(new_string)

print(counter_data)
print(counter_data.items())
print(counter_data.values())
print(counter_data.keys())