from collections import Counter
import csv 

#opening the csv file and reading from it
#f=open("   ")
with open("hw.csv", newline='') as f:
    reader=csv.reader(f)
    file_data=list(reader)

#removing / pop of the first row which is the col names
file_data.pop(0)

new_data=[]

for i in range(len(file_data)):
    num=file_data[i][1]
    new_data.append(num)


data= Counter(new_data)


#creating data range buckets
moderanges={
    "50-60":0,
    "60-70":0,
    "70-80":0
}

#filling up the heights in the range buckets
for height, occurence in data.items():
    if 50 < float(height) <60 :
        moderanges["50-60"]+=occurence
    if 60 < float(height) <70 :
        moderanges["60-70"]+=occurence
    if 70 < float(height) <80 :
        moderanges["70-80"]+=occurence

ans_range, ans_occurance=0,0

print(moderanges)

#which ranhe has the hghtes number of occurance
for range,occurence in moderanges.items():
    if occurence>ans_occurance:
        ans_range=[int(range.split("-")[0]),int(range.split("-")[1])]
        ans_occurance=occurence

# upper limit and lower limit average is the mode
ans_mode=((ans_range[0]+ans_range[1])/2)

print("mode= "+str(ans_mode))






