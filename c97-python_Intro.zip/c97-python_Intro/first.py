pocketmoney=int(input("Enter the amount"))
if(pocketmoney<100):
    print("I feel you")
elif(pocketmoney>100 and pocketmoney<500):
    print("Thats nice")
else:
    print("Richie rich")