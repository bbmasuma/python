import random
import statistics
import plotly.figure_factory as ff

sum_dice=[]
for i in range(0,1000):
    dice1=random.randint(1,6)
    dice2=random.randint(1,6)
    sum_dice.append(dice1+dice2)

mean= sum(sum_dice)/ len(sum_dice)
std_deviation = statistics.stdev(sum_dice)
median = statistics.median(sum_dice)
mode = statistics.mode(sum_dice)

print(mean,median,mode,std_deviation)

fig = ff.create_distplot([sum_dice], ["dice scores"], show_hist=False)

fig.show()