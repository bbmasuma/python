import plotly.figure_factory as ff
import plotly.graph_objects as go
import pandas as pd
import statistics



df = pd.read_csv("data.csv")
height = df["Height(Inches)"].tolist()

height_mean = sum(height) / len(height)
std_deviation = statistics.stdev(height)

first_std_deviation_start, first_std_deviation_end = height_mean-std_deviation, height_mean+std_deviation
second_std_deviation_start, second_std_deviation_end = height_mean-(2*std_deviation), height_mean+(2*std_deviation)

list_of_data_within_1_std_deviation = [result for result in height if result > first_std_deviation_start and result < first_std_deviation_end]
list_of_data_within_2_std_deviation = [result for result in height if result > second_std_deviation_start and result < second_std_deviation_end]


print("Mean of this data is {}".format(height_mean))
print("Standard deviation of this data is {}".format(std_deviation))

print("{}% of data lies within 1 standard deviation".format(len(list_of_data_within_1_std_deviation)*100.0/len(height)))
print("{}% of data lies within 2 standard deviations".format(len(list_of_data_within_2_std_deviation)*100.0/len(height)))

fig = ff.create_distplot([height], ["Height"], show_hist=False)
fig.add_trace(go.Scatter(x=[height_mean, height_mean], y=[0, 0.17], mode="lines", name="MEAN"))
fig.add_trace(go.Scatter(x=[first_std_deviation_start, first_std_deviation_start], y=[0, 0.17], mode="lines", name="STANDARD DEVIATION 1"))
fig.add_trace(go.Scatter(x=[first_std_deviation_end, first_std_deviation_end], y=[0, 0.17], mode="lines", name="STANDARD DEVIATION 1"))
fig.add_trace(go.Scatter(x=[second_std_deviation_start, second_std_deviation_start], y=[0, 0.17], mode="lines", name="STANDARD DEVIATION 2"))
fig.add_trace(go.Scatter(x=[second_std_deviation_end, second_std_deviation_end], y=[0, 0.17], mode="lines", name="STANDARD DEVIATION 2"))
fig.show()