import os
import shutil

source=input("Enter source")
destination=input("Enter destination")

source=source+'/'
destination=destination+'/'

filelist=os.listdir(source)

for file in filelist:
    shutil.copy((source+file),destination)