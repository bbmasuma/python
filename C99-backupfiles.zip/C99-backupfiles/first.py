import os
path=r"C:\Users\home\Desktop\WhiteHat Jr\C99-backupfiles\A\car1.png"
isExist=os.path.exists(path)
print(isExist)

rootext=os.path.splitext(path)
print("path:",rootext[0])
print("extension:",rootext[1])

print(os.listdir())
