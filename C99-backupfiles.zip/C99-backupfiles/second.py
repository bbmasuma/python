import os
import shutil

source=r"C:\Users\home\Desktop\WhiteHat Jr\C99-backupfiles\A\test1.txt"
destination=r"C:\Users\home\Desktop\WhiteHat Jr\C99-backupfiles\B"

dest=shutil.copy(source, destination)

source=r"C:\Users\home\Desktop\WhiteHat Jr\C99-backupfiles\A\car1.png"
destination=r"C:\Users\home\Desktop\WhiteHat Jr\C99-backupfiles\B"

dest=shutil.move(source, destination)