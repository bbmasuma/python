class Car(object):
    def __init__(self,color,company, speed, model):
        self.color=color
        self.company=company
        self.speed=speed
        self.model=model

    def start(self):
        return "Started"

    def stop(self):
        return "stopped"

    def getColor(self):
        return (self.color)


AudiXD = Car("red", "Audi", 600, "XD")

# Now we can get to the grades easily
print(AudiXD.start())
print(AudiXD.getColor())
print(AudiXD.stop())