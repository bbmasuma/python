import csv
import numpy

with open("coffeesleep.csv", newline='') as f:
    reader=csv.reader(f)
    file_data=list(reader)

file_data.pop(0)

coffee=[]
sleep=[]

for i in file_data:
    coffee.append(float(i[1]))
    sleep.append(float(i[2]))

coorelation=numpy.corrcoef(coffee,sleep)

print(coorelation)