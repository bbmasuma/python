import csv
import numpy as np

with open("coffeesleep.csv", newline='') as f:
    reader=csv.reader(f)
    file_data=list(reader)

file_data.pop(0)

coffee=[]
s=[]

for i in file_data:
    coffee.append(float(i[1]))
    s.append(float(i[2]))


coffee=np.array(coffee)
s=np.array(s)

ans= np.corrcoef(coffee, s)

print(ans[0][1])
